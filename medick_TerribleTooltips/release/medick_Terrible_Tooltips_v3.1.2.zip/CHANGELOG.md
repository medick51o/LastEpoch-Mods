# MedicK's Terrible Tooltips v3.1.2 — Season 5 compatibility

- Rebuilt for Season 5 and includes the shared Terrible Interop Repair plugin.
- Updated dropped-item label patch for the game method that no longer takes a boolean parameter.
- Updated item identity handling for the new 32-bit individualID, fixing the old missing-method error on hover.
- Updated multi-stat affix lookup to the Season 5 master affix list API.
- Retains the v3.1.1 tooltip lifecycle improvements and existing settings.

Installation: extract the ZIP into the Last Epoch game folder. The mod goes in Mods/ and the identical shared repair plugin goes in Plugins/. One plugin copy serves all Terrible mods. Close the game before installing.

