# MedicK's Terrible fog_OF_war v1.0.2 — Season 5 compatibility

- Updated for Season 5 and rebuilt against the current game assemblies.
- Includes Terrible Interop Repair to resolve the shared CoreModule startup failure.
- The shared repair keeps a backup and handles regenerated CoreModule files.
- Existing vision settings and DLL filename are preserved.

Installation: extract the ZIP into the Last Epoch game folder. The mod goes in Mods/ and the identical shared repair plugin goes in Plugins/. One plugin copy serves all Terrible mods. Close the game before installing.

